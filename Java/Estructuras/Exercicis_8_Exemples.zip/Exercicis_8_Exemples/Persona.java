/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicis_8_Exemples;

/**
 *
 * @author David
 */
public class Persona {
    
    String nom;
    String cognom;
    String dni;
    int mida;
    double pes;
    
}
