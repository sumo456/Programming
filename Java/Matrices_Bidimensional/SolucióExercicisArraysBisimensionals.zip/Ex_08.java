package Exercicis_6;

import java.util.Random;

public class Ex_08 {

    public static void main(String[] args) {

        Random rd = new Random();
        int matriu[][] = new int[5][5];
        int sumaFila, sumaCol;

        for (int i = 0; i < matriu.length; i++) {
            for (int j = 0; j < matriu[i].length; j++) {
                matriu[i][j] = rd.nextInt(5);
            }
        }

        // Suma fila i columna        
        for (int i = 0; i < matriu.length; i++) {
            sumaFila = 0;
            sumaCol = 0;
            for (int j = 0; j < matriu[i].length; j++) {
                sumaFila = sumaFila + matriu[i][j];
                sumaCol = sumaCol + matriu[j][i];
                System.out.print(matriu[i][j] + "  ");
            }
            System.out.print("---> Fila = " + sumaFila);
            System.out.println(" i Columna = " + sumaCol);

        }

    }
}
