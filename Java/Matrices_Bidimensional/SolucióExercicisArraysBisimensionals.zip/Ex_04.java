/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicis_6;

/**
 *
 * @author david
 */
public class Ex_04 {

  
    public static void main(String[] args) {

        int m[][] = new int[5][8];

        for (int i = 0; i < m.length; i++) {

            System.out.printf("|");

            for (int j = 0; j < m[i].length; j++) {

                m[i][j] = i + j;
                System.out.printf("%3d", m[i][j]);
            }
            
            System.out.printf("  |\n");

        }
    }
}
