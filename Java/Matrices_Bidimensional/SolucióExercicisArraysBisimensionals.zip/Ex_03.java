
package Exercicis_6;


public class Ex_03 {

    
    public static void main(String[] args) {
        
        int m[][] = {{23, 45, 11, 2}, {67, 2,},{1, 2, 3, 4, 5, 6, 7},};
        
        for (int i = 0; i < m.length; i++) {            
            
            System.out.printf("Fila: %3d --> ",i);
            
            for (int j = 0; j < m[i].length; j++) {
                
                System.out.printf("%4d",m[i][j]);
            }
            System.out.println("");
        }   
    }
    
}
