
package Exercicis_6;

/**
 *
 * @author david
 */
public class Ex_05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int m[][] = new int[5][5];
        
        for (int i = 0; i < m.length; i++) {            
            
            System.out.printf("|");
            
            for (int j = 0; j < m[i].length; j++) {
                
                m[i][j]=i*j;
                System.out.printf("%5d",m[i][j]);
            }
            System.out.printf("  |\n");            
        }   

    }
    
}
