package Exercicis_6;

public class Ex_02 {

    public static void main(String[] args) {

        int m[][] = {{1, 2, 3}, {4, 5, 6}};

        System.out.println("Per files");
        System.out.println("---------");
        
        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {

                System.out.printf("%2d", m[i][j]);
            }
            System.out.println("");
        }

        System.out.println("\nPer columnes");
        System.out.println("------------");

        for (int j = 0; j < m[0].length; j++) {
            for (int i = 0; i < m.length; i++) {

                System.out.printf("%2d", m[i][j]);
            }
            System.out.println("");
        }

    }

}
