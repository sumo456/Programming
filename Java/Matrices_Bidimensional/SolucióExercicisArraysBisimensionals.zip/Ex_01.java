package Exercicis_6;

public class Ex_01 {

    public static void main(String[] args) {

        int[][] m = new int[6][6];
        int i, j, prova = 1;

        for (j = 0; j < m[0].length; j++) {

            for (i = 0; i < m.length; i++) {

                m[i][j] = prova;
                prova++;
            }
        }

        for (i = 0; i < m.length; i++) {

            for (j = 0; j < m[0].length; j++) {

                System.out.printf("%5d", m[i][j]);
            }
            System.out.println("");
        }
    }
}
