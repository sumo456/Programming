package Exercicis_6;

import java.util.Random;

/**
 *
 * @author david
 */
public class Ex_09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int m[][] = new int[3][3];
        Random rd = new Random();
        boolean esSimetrica = true;
        int i, j;

        //Assina valors a la matriu
        for (i = 0; i < m.length; i++) {
            for (j = 0; j < m[i].length; j++) {
                m[i][j] = rd.nextInt(2);
            }
        }

        //Imprimeix la matriu
        for (i = 0; i < m.length; i++) {
            for (j = 0; j < m[i].length; j++) {
                System.out.printf("%5d", m[i][j]);
            }
            System.out.printf("\n\n");
        }

        int f = 0;
        int c;
        
        //Comprova si es simètrica        
        while (esSimetrica && f < m.length) {
            c = 0;
            while (esSimetrica && c < m[f].length) {
                if (m[f][c] != m[c][f]) {
                    esSimetrica = false;
                }
                c++;                
            }
            f++;            
        }
        

        if (esSimetrica) {
            System.out.println("La matriu és simètrica\n");
        } else {
            System.out.println("No és simètrica\n");
        }
    }
}
