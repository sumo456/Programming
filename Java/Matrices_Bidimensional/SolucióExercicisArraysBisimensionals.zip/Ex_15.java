/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicis_6;

import java.util.Scanner;

/**
 *
 * @author david
 */
public class Ex_15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        Scanner sc = new Scanner (System.in);
        int nFil, nCol;
         int[][] matriu;
         int[] acumCol;
       
        System.out.println("Introdueix la dimensió de la matriu. ");
        
        System.out.print("Número de files: ");        
        nFil = sc.nextInt();
        
        System.out.print("Número de columnes: ");
        nCol = sc.nextInt();
        
        matriu = new int [nFil][nCol];
        acumCol = new int [nCol];
        
       
        //  Omplim la taula matriu
        for (int i = 0; i < matriu.length; i++) {
            for (int j = 0; j < matriu[i].length; j++) {
                System.out.print("Element " +i +"," +j +": ");
                matriu [i][j] = sc.nextInt(); 
            }
        }
        // Calculem total per columnes i ho guardem en el vector acumCol
       
        for (int j = 0; j < nCol; j++) {
            //acumCol[j]=0;
            for (int i = 0; i < nFil; i++) {
                acumCol[j] +=  matriu[i][j];
            }
        }
        //  Mostem la taula
        for (int i = 0; i< matriu.length; i++) {
            for (int j = 0; j < matriu[j].length; j++) {
                System.out.printf("%3d ", matriu[i][j]);
            }
            System.out.println();
        }
        //Mostem el resultats
        System.out.println("La suma per columnes de la matriu a1: ");
        for (int i = 0; i < acumCol.length; i++) {
                System.out.printf("%3d ", acumCol[i]);
        }
        System.out.println("");
        
    }
    
}
