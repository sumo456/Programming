/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicis_6;

/**
 *
 * @author pcdavid
 */
public class Ex_06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int m[][] = new int[8][6];

        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {

                if (i == 0 || i == m.length - 1 || j == 0 || j == m[0].length - 1) {
                    m[i][j] = 1;

                } else {
                    m[i][j] = 0;
                }
            }
        }
        
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                System.out.print(m[i][j]);
                
            }
            System.out.println("");
        }
        
        
        


    }

}
