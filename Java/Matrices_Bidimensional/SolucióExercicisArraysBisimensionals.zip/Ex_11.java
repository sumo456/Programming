/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicis_6;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author pcdavid
 */
public class Ex_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random rd = new Random();
        boolean positiva;
        int matriu[][];
        int files, columnes;

        //Es demanen les dimensions a l'usuari
        System.out.println("Introdueix les dimensions de la matriu. ");
        System.out.print("Files   : ");
        files = sc.nextInt();
        System.out.print("\nColumnes: ");
        columnes = sc.nextInt();

        matriu = new int[files][columnes];

        //Es demanen els elements
        for (int i = 0; i < matriu.length; i++) {
            for (int j = 0; j < matriu[i].length; j++) {
                matriu[i][j] = rd.nextInt(41) - 10;
                System.out.print(" " + matriu[i][j]);
            }
            System.out.println("");
        }

        //Es comprova si és positiva        
        positiva = true;
        int i = 0;
        int j;

        while (i < matriu.length && positiva) {
            j = 0;
            while (j < matriu[i].length && positiva) {
                if (matriu[i][j] < 0) {
                    positiva = false;
                    System.out.println("La matriu no és positiva !!!");
                }
                j++;
            }
            i++;
        }

        if (positiva) {
            System.out.println("La matriu és positiva !!!");

        }
    }

}
