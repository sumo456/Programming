package Exercicis_6;

import java.util.Random;
import java.util.Scanner;

public class Ex_10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random rd = new Random();
        boolean nula;
        int matriu[][];
        int files, columnes;

        //Es demanen les dimensions a l'usuari
//        System.out.println("Introdueix les dimensions de la matriu. ");
//        System.out.print("Files   : ");
//        files = sc.nextInt();
//        System.out.print("\nColumnes: ");
//        columnes = sc.nextInt();

        matriu = new int[2][2];

        //Es demanen els elements
        for (int i = 0; i < matriu.length; i++) {
            for (int j = 0; j < matriu[i].length; j++) {
                matriu[i][j] = rd.nextInt(2);
                System.out.print(" " + matriu[i][j]);
            }
            System.out.println("");
        }

        //Es comprova si és nul.la
        nula = false;
        int i = 0;
        int j;

        while (i < matriu.length && nula == false) {
            j = 0;
            while (j < matriu[i].length && !nula) {
                if (matriu[i][j] != 0) {
                    nula = true;
                    System.out.println("La matriu no és nul.la !!!");
                }
                j++;
            }
            i++;
        }
        if (!nula) {
            System.out.println("La matriu és nul.la !!!");
        }

    }

}
