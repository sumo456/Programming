package Exercicis_6;

import java.util.Scanner;


public class Ex_07 {

    
    public static void main(String[] args) {
        
        final int mida = 3;
        Scanner sc = new Scanner(System.in);
        int a[][], b[][], suma[][];
        int i, j;
        a = new int[mida][mida];
        b = new int[mida][mida];
        suma = new int[mida][mida];

        System.out.println("Matriu A:");
        for (i = 0; i < a.length; i++) {
            for (j = 0; j < a[i].length; j++) {
                System.out.print("A[" + i + "][" + j + "]: ");
                a[i][j] = sc.nextInt();
            }
        }
        System.out.println("Matriu B:");
        for (i = 0; i < b.length; i++) {
            for (j = 0; j < b[i].length; j++) {
               System.out.print("B[" + i + "][" + j + "]: ");
                b[i][j] = sc.nextInt();
            }
        }

        // Fem la suma i la mostrem per pantalla
        
        for (i = 0; i < suma.length; i++) {
            for (j = 0; j < suma[i].length; j++) {
                suma[i][j] = a[i][j] + b[i][j];
                System.out.printf("%3d ", suma[i][j]);
            }
            System.out.println();
        }        
    }    
}
