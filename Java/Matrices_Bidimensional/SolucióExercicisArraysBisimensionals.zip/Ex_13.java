/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicis_6;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author david
 */
public class Ex_13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random rd = new Random();
        boolean matriuDiagonal = true;
        int matriu[][];
        int files, columnes;

        //Es demanen les dimensions a l'usuari
        System.out.println("Introdueix les dimensions de la matriu. ");
        System.out.println("Files   : ");
        files = sc.nextInt();
        System.out.println("Columnes: ");
        columnes = sc.nextInt();

        matriu = new int[files][columnes];

        //Es demanen els elements i es mostren per pantalla
        for (int i = 0; i < matriu.length; i++) {
            for (int j = 0; j < matriu[i].length; j++) {
                matriu[i][j] = rd.nextInt(2);
                System.out.print(matriu[i][j] + " ");
            }
            System.out.println("");
        }

        //Es comprova si és diagonal
        for (int i = 0; i < matriu.length; i++) {
            for (int j = 0; j < matriu[i].length; j++) {
                //Si els elements fora de la diagonal no son 0
                if (i != j && matriu[i][j] != 0) {
                    matriuDiagonal = false;                    
                }              
                
            }
        }
        if (matriuDiagonal) {
            System.out.println("La matriu és diagonal !!!");
        } else {
            System.out.println("No és diagonal");
        }

    }

}
