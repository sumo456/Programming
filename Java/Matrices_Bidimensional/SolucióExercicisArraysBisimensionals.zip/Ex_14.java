/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicis_6;


import java.util.Scanner;

/**
 *
 * @author david
 */
public class Ex_14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int matriu[][], sumaFiles[];
        int files, columnes;

        //Es demanen les dimensions a l'usuari
        System.out.println("Introdueix les dimensions de la matriu. ");
        System.out.print("Files   : ");
        files = sc.nextInt();
        System.out.print("Columnes: ");
        columnes = sc.nextInt();
        matriu = new int[files][columnes];
        sumaFiles = new int[files];

        //Es demanen els elements de la matriu
        for (int i = 0; i < matriu.length; i++) {
            for (int j = 0; j < matriu[i].length; j++) {
                System.out.println("Introdueix un valor");
                matriu[i][j] = sc.nextInt();
            }
        }

        //Calculem la suma 
        for (int i = 0; i < matriu.length; i++) {
            for (int j = 0; j < matriu[i].length; j++) {
                sumaFiles[i] += matriu[i][j];
            }

        }

        for (int i = 0; i < sumaFiles.length; i++) {
            System.out.print(sumaFiles[i] + " ");
        }

    }
}
